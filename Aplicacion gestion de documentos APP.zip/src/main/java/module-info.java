module com.example.docvault {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires javafx.base;
    requires java.desktop;


    opens com.example.docvault to javafx.fxml;
    exports com.example.docvault;
}