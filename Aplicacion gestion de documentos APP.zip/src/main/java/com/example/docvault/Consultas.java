package com.example.docvault;
import javax.swing.*;
import java.io.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class Consultas {
    static DBConnection dbConnection = new DBConnection();

    public static void checkUser(ArrayList<Usuario> usuarios) {
        usuarios.clear();
        String sql = "SELECT * FROM usuarios";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String email = rs.getString("email");
                String contraseña = rs.getString("contraseña");
                String rol = rs.getString("rol");
                usuarios.add(new Usuario( nombre, email, contraseña, rol));
            }
        } catch (SQLException e) {
            System.out.println("Error al listar usuarios: " + e.getMessage());
        }
    }

    public static void addUser(String nombre, String email, String contraseña, String rol) {
        String sqlInsert = "INSERT INTO usuarios (nombre, email, contraseña, rol) VALUES (?, ?, ?, ?)";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert)) {

            pstmtInsert.setString(1, nombre);
            pstmtInsert.setString(2, email);
            pstmtInsert.setString(3, contraseña);
            pstmtInsert.setString(4, rol);

            pstmtInsert.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al añadir el usuario: " + e.getMessage());
        }
    }

    public static void deleteUser(String name, String rol) {
        String sqlDelete = "DELETE FROM usuarios WHERE nombre = ? AND rol = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtDelete = conn.prepareStatement(sqlDelete)) {

            pstmtDelete.setString(1, name);
            pstmtDelete.setString(2, rol);

            int rowsAffected = pstmtDelete.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Usuario eliminado con éxito.");
            } else {
                System.out.println("No se encontró ningún usuario con ese nombre y rol.");
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar el usuario: " + e.getMessage());
        }
    }

    public static void editUser(String newName, String email, String contraseña, String rol, String oldName) {
        String sqlUpdate = "UPDATE usuarios SET nombre = ?, email = ?, contraseña = ?, rol = ? WHERE nombre = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate)) {

            pstmtUpdate.setString(1, newName);
            pstmtUpdate.setString(2, email);
            pstmtUpdate.setString(3, contraseña);
            pstmtUpdate.setString(4, rol);
            pstmtUpdate.setString(5, oldName);

            int rowsAffected = pstmtUpdate.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Usuario actualizado con éxito.");
            } else {
                System.out.println("No se encontró ningún usuario con ese nombre.");
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar el usuario: " + e.getMessage());
        }
    }


    public static void checkProyectos(ArrayList<Proyecto> proyectos) {
        proyectos.clear();
        String sql = "SELECT * FROM proyectos";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                Date fecha_creacion = rs.getDate("fecha_creacion");
                Date fecha_inicio = rs.getDate("fecha_inicio");
                Date fecha_fin = rs.getDate("fecha_fin");
                String codigo_proyecto = rs.getString("codigo_proyecto");
                String palabras_clave = rs.getString("palabras_clave");
                String tipo_proyecto = rs.getString("tipo_proyecto");
                boolean activo = rs.getBoolean("activo");
                int calificacion = rs.getInt("calificacion");
                String auditoria = rs.getString("auditora");
                String codigo = rs.getString("codigo");
                boolean en_cooperacion = rs.getBoolean("en_cooperacion");
                int bajada_calificacion = rs.getInt("bajada_calificacion");
                String fases = rs.getString("fases");

                proyectos.add(new Proyecto(id, nombre, fecha_creacion, fecha_inicio, fecha_fin,
                        codigo_proyecto, palabras_clave, tipo_proyecto, activo, calificacion,
                        auditoria, codigo, en_cooperacion, bajada_calificacion, fases));
            }
        } catch (SQLException e) {
            System.out.println("Error al listar proyectos: " + e.getMessage());
        }
    }

    public static void addProyectos(Proyecto proyecto) {
        String sqlInsert = "INSERT INTO proyectos (nombre, fecha_creacion, fecha_inicio, fecha_fin, codigo_proyecto, " +
                "palabras_clave, tipo_proyecto, activo, calificacion, auditora, codigo, en_cooperacion, " +
                "bajada_calificacion, fases) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert)) {

            pstmtInsert.setString(1, proyecto.getNombre());
            pstmtInsert.setDate(2, new java.sql.Date(proyecto.getFechaCreacion().getTime()));
            pstmtInsert.setDate(3, new java.sql.Date(proyecto.getFechaInicio().getTime()));
            pstmtInsert.setDate(4, new java.sql.Date(proyecto.getFechaFin().getTime()));
            pstmtInsert.setString(5, proyecto.getCodigoProyecto());
            pstmtInsert.setString(6, proyecto.getPalabrasClave());
            pstmtInsert.setString(7, proyecto.getTipoProyecto());
            pstmtInsert.setBoolean(8, proyecto.isActivo());
            pstmtInsert.setInt(9, proyecto.getCalificacion());
            pstmtInsert.setString(10, proyecto.getAuditora());
            pstmtInsert.setString(11, proyecto.getCodigo());
            pstmtInsert.setBoolean(12, proyecto.isEnCooperacion());
            pstmtInsert.setInt(13, proyecto.getBajadaCalificacion());
            pstmtInsert.setString(14, proyecto.getFases());

            int rowsInserted = pstmtInsert.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Proyecto añadido con éxito.");
            }
        } catch (SQLException e) {
            System.out.println("Error al añadir el proyecto: " + e.getMessage());
        }
    }

    public static void editProyecto(String code, String row, String data) {
        String sqlUpdate = "UPDATE proyectos SET " + row + " = ? WHERE codigo_proyecto = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate)) {

            pstmtUpdate.setString(1, data);
            pstmtUpdate.setString(2, code);

            int rowsAffected = pstmtUpdate.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Proyecto actualizado con éxito.");
            } else {
                System.out.println("No se encontró ningún proyecto con ese código.");
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar el proyecto: " + e.getMessage());
        }
    }

    public static void activo(String code, String row, int data) {
        String sqlUpdate = "UPDATE proyectos SET " + row + " = ? WHERE codigo_proyecto = ?";
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate)) {
            pstmtUpdate.setInt(1, data);
            pstmtUpdate.setString(2, code);
            int rowsAffected = pstmtUpdate.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Proyecto actualizado con éxito.");
            } else {
                System.out.println("No se encontró ningún proyecto con ese código.");
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el proyecto: " + e.getMessage());
        }
    }

    public static void deleteProyectos(String codigoProyecto) {
        String sqlDelete = "DELETE FROM proyectos WHERE codigo_proyecto = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtDelete = conn.prepareStatement(sqlDelete)) {

            pstmtDelete.setString(1, codigoProyecto);

            int rowsDeleted = pstmtDelete.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Proyecto eliminado con éxito.");
            } else {
                System.out.println("No se encontró ningún proyecto con ese código para eliminar.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el proyecto: " + e.getMessage());
        }
    }

    public static void deleteRelacionados(int idProyecto){
        String sqlDelete = "DELETE * FROM documentos WHERE proyecto_id = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtDelete = conn.prepareStatement(sqlDelete)) {

            pstmtDelete.setInt(1, idProyecto);

            int rowsDeleted = pstmtDelete.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Documentos eliminados con éxito.");
            } else {
                System.out.println("No se encontró ningún documento con ese proyecto para eliminar.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar los documentos: " + e.getMessage());
        }
    }

    public static void deleteRelacionados2(int idProyecto){
        String sqlDelete = "DELETE * FROM estadisticas_acceso WHERE proyecto = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtDelete = conn.prepareStatement(sqlDelete)) {

            pstmtDelete.setInt(1, idProyecto);

            int rowsDeleted = pstmtDelete.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Estadisticas eliminadas con éxito.");
            } else {
                System.out.println("No se encontró ninguna estadistica relacionada a ese proyecto para eliminar.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar las estadisticas: " + e.getMessage());
        }
    }

    public static void checkDocument(int id, ArrayList<Documento> documentos) {
        documentos.clear();
        String sql = "SELECT * FROM documentos WHERE proyecto_id = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String nombre = rs.getString("nombre_documento");
                    Date fecha_creacion = rs.getDate("fecha_creacion");
                    Blob documentoBlob = rs.getBlob("documento");
                    documentos.add(new Documento(nombre, fecha_creacion, documentoBlob));
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al listar documentos: " + e.getMessage());
        }
    }

    public static void editDocument(int id, String newName, String oldName) {
        String sqlUpdate = "UPDATE documentos SET nombre_documento = ? WHERE proyecto_id = ? AND nombre_documento = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate)) {

            pstmtUpdate.setString(1, newName);
            pstmtUpdate.setInt(2, id);
            pstmtUpdate.setString(3, oldName);

            int rowsAffected = pstmtUpdate.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Documento actualizado con éxito.");
            } else {
                System.out.println("No se encontró ningún Documento con ese nombre.");
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar el Documento: " + e.getMessage());
        }
    }

    public static void deleteDocument(int id, String name) {
        String sqlDelete = "DELETE FROM documentos WHERE proyecto_id = ? AND nombre_documento = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtDelete = conn.prepareStatement(sqlDelete)) {

            pstmtDelete.setInt(1, id);
            pstmtDelete.setString(2, name);

            int rowsAffected = pstmtDelete.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Documento eliminado con éxito.");
            } else {
                System.out.println("No se encontró ningún documento en ese proyecto y con ese nombre.");
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar el documento: " + e.getMessage());
        }
    }

    public static void deleteRelacionadoDoc(String docName){
        String sqlDelete = "DELETE * FROM estadisticas_acceso WHERE documento = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtDelete = conn.prepareStatement(sqlDelete)) {

            pstmtDelete.setString(1, docName);

            int rowsDeleted = pstmtDelete.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Estadisticas eliminadas con éxito.");
            } else {
                System.out.println("No se encontró ninguna estadistica relacionada a ese proyecto para eliminar.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar las estadisticas: " + e.getMessage());
        }
    }

    public static void addDocument(int proyecto_id, File doc) {
        String sqlInsert = "INSERT INTO documentos (proyecto_id, nombre_documento, fecha_creacion, documento) VALUES (?, ?, ?, ?)";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert);
             FileInputStream fis = new FileInputStream(doc)) {
            LocalDate fecha_creacion = LocalDate.now();

            pstmtInsert.setInt(1, proyecto_id);
            pstmtInsert.setString(2, doc.getName());
            pstmtInsert.setDate(3, Date.valueOf(fecha_creacion));
            pstmtInsert.setBinaryStream(4, fis, (int) doc.length());

            pstmtInsert.executeUpdate();

        } catch (SQLException | IOException e) {
            System.out.println("Error al añadir el documento: " + e.getMessage());
        }
    }

    public static void downloadDocument(int id, String nombreArchivo) {
        String sql = "SELECT documento FROM documentos WHERE proyecto_id = ? AND nombre_documento = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                byte[] documento = resultSet.getBytes("documento");
                try (FileOutputStream fos = new FileOutputStream(nombreArchivo)) {
                    fos.write(documento);
                    System.out.println("Documento descargado exitosamente: " + nombreArchivo);
                } catch (IOException e) {
                    System.err.println("Error al guardar el documento: " + e.getMessage());
                }
            } else {
                System.out.println("No se encontró el documento con ID de proyecto: " + id);
            }
        } catch (Exception e) {
            System.err.println("Error al descargar el documento: " + e.getMessage());
        }
    }

    public static void registrarAcceso(int proyectoId, String usuarioCorreo, String documentoNombre) {
        String sqlInsert = "INSERT INTO estadisticas_acceso (documento, proyecto, usuario) VALUES (?, ?, ?);";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert)) {

            pstmtInsert.setString(1, documentoNombre);
            pstmtInsert.setInt(2, proyectoId);
            pstmtInsert.setString(3, usuarioCorreo);

            pstmtInsert.executeUpdate();
            System.out.println("Acceso al documento registrado exitosamente.");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al registrar el acceso al documento");
        }
    }

    // Método para registrar la auditoría
    public static void registrarAuditoria(String usuarioEmail, String accion) {
        String sql = "INSERT INTO auditoria (usuario_id, accion) VALUES (?, ?);";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuarioEmail);
            stmt.setString(2, accion);

            stmt.executeUpdate();
            System.out.println("Auditoría registrada correctamente.");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al registrar la auditoría");
        }
    }

    public static void checkAuditoria(ArrayList<String> logs) {
        logs.clear();
        String sql = "SELECT * FROM auditoria";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String txt = rs.getString("accion");
                logs.add(txt);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar usuarios: " + e.getMessage());
        }
    }

}