package com.example.docvault;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;

public class GráficasVP extends Application {
    int activos;
    int inactivos;
    int data0;
    int data1;
    int data2;
    int data3;
    int data4;
    int data5;
    int data6;
    int data7;
    int data8;
    int data9;
    int data10;
    int admin;
    int lector;
    int escritor;
    ArrayList<Proyecto> proyects = new ArrayList<>();
    ArrayList<Usuario> users = new ArrayList<>();

    @Override
    public void start(Stage grafStage) throws Exception {

        Consultas.checkProyectos(proyects);
        Consultas.checkUser(users);

        VBox box = new VBox();
        Label proyectosLabel = new Label("Proyectos: " + proyects.size());
        Label usersLabel = new Label("Usuarios: " + users.size());
        box.getChildren().addAll(proyectosLabel, usersLabel);

        VBox nameTag = new VBox();

        Label nameLabel = new Label();
        nameLabel.setText(Usuario.usuario.getNombre());
        Label roleLabel = new Label();
        roleLabel.setText(Usuario.usuario.getRol());

        nameTag.getChildren().addAll(nameLabel, roleLabel);

        datos();

        PieChart actives = new PieChart();
        actives.getData().addAll(
                new PieChart.Data("Activos: " + activos, activos),
                new PieChart.Data("Inactivos: " + inactivos, inactivos)
        );
        actives.setTitle("Proyectos");

        PieChart usersChart = new PieChart();
        usersChart.getData().addAll(
                new PieChart.Data("Administradores: " + admin, admin),
                new PieChart.Data("Lectores: " + lector, lector),
                new PieChart.Data("Escritores: " + escritor, escritor)
        );
        usersChart.setTitle("Usuarios");

        PieChart notas = new PieChart();
        notas.getData().addAll(
                new PieChart.Data("0: " + data0, data0),
                new PieChart.Data("1: " + data1, data1),
                new PieChart.Data("2: " + data2, data2),
                new PieChart.Data("3: " + data3, data3),
                new PieChart.Data("4: " + data4, data4),
                new PieChart.Data("5: " + data5, data5),
                new PieChart.Data("6: " + data6, data6),
                new PieChart.Data("7: " + data7, data7),
                new PieChart.Data("8: " + data8, data8),
                new PieChart.Data("9: " + data9, data9),
                new PieChart.Data("10: " + data10, data10)
        );
        notas.setTitle("Nota de proyectos");

        GridPane gp = new GridPane();
        gp.add(nameTag, 2, 0);
        gp.add(notas, 0, 2);
        gp.add(usersChart, 1, 2);
        gp.add(actives, 2, 2);
        gp.add(box, 1, 0);
        gp.setHgap(10);
        gp.setVgap(10);
        gp.setAlignment(Pos.CENTER);

        Scene scene = new Scene(gp, 1300, 700);
        grafStage.setTitle("DocVault-Gráficas");
        grafStage.setScene(scene);
        grafStage.show();
    }

    public void datos(){
        admin = 0;
        lector = 0;
        escritor = 0;
        activos = 0;
        inactivos = 0;
        data0 = 0;
        data1 = 0;
        data2 = 0;
        data3 = 0;
        data4 = 0;
        data5 = 0;
        data6 = 0;
        data7 = 0;
        data8 = 0;
        data9 = 0;
        data10 = 0;
        for (Usuario u : users){
            if(u.getRol().equals("Administrador")){
                admin++;
            }
            if(u.getRol().equals("Lector")){
                lector++;
            }
            if(u.getRol().equals("Escritor")){
                escritor++;
            }
        }
        for(Proyecto p : proyects){
            switch(p.getCalificacion()){
                case 0: data0++; break;
                case 1: data1++; break;
                case 2: data2++; break;
                case 3: data3++; break;
                case 4: data4++; break;
                case 5: data5++; break;
                case 6: data6++; break;
                case 7: data7++; break;
                case 8: data8++; break;
                case 9: data9++; break;
                case 10: data10++; break;
            }
            if(p.isActivo()){
                activos++;
            }else{
                inactivos++;
            }
        }
    }
}