package com.example.docvault;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.swing.*;

public class EscritorP extends Application {
    // Lista de proyectos y lista observable para la interfaz gráfica
    static ArrayList<Proyecto> proyects = new ArrayList<>();
    static ObservableList<String> dataproyects = FXCollections.observableArrayList();

    // Proyecto seleccionado por defecto
    Proyecto selProyect = new Proyecto(420, "N/A", Date.valueOf("2024-01-01"),
            Date.valueOf("2024-01-15"), Date.valueOf("2024-06-30"), "N/A-2024-001",
            "N/A, N/A, N/A", "N/A", false, 9,
            "Auditoria N/A", "N/A-123456", true, 2, "N/A, N/A, N/A");

    // Etiquetas para mostrar los detalles del proyecto
    Label nombreLabel = new Label();
    Label fechaCreacionLabel = new Label();
    Label fechaInicioLabel = new Label();
    Label fechaFinLabel = new Label();
    Label codigoProyectoLabel = new Label();
    Label palabrasClaveLabel = new Label();
    Label tipoProyectoLabel = new Label();
    Label activoLabel = new Label();
    Label calificacionLabel = new Label();
    Label auditoraLabel = new Label();
    Label codigoLabel = new Label();
    Label enCooperacionLabel = new Label();
    Label bajadaCalificacionLabel = new Label();
    Label fasesLabel = new Label();

    @Override
    public void start(Stage primaryStage) {
        // Verifica y carga los proyectos desde la base de datos
        Consultas.checkProyectos(proyects);

        // Configuración del layout principal
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));

        // Panel izquierdo: Búsqueda y lista de proyectos
        VBox vboxL = new VBox(10);
        TextField bBusqueda = new TextField();
        bBusqueda.setPromptText("Búsqueda");
        ComboBox<String> cbFiltro = new ComboBox<>();
        cbFiltro.getItems().addAll("Todos", "Activo", "Inactivo", "En cooperación", "Sin cooperación");
        cbFiltro.setValue("Activo");
        ListView<String> proyectsListView = new ListView<>();
        proyectsListView.setItems(dataproyects);
        // Filtro de búsqueda

        vboxL.getChildren().addAll(bBusqueda, proyectsListView);
        Button deleteButton = new Button("Borrar proyecto");

        // Panel central: Detalles del proyecto seleccionado
        VBox vboxC = new VBox(10);
        vboxC.setPadding(new Insets(10));
        nombreLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        vboxC.getChildren().addAll(cbFiltro, nombreLabel, fechaCreacionLabel, fechaInicioLabel, fechaFinLabel, codigoProyectoLabel, palabrasClaveLabel, tipoProyectoLabel, activoLabel, calificacionLabel, auditoraLabel, codigoLabel, enCooperacionLabel, bajadaCalificacionLabel, fasesLabel, deleteButton);

        // Listener para actualizar los detalles del proyecto cuando se selecciona uno en la lista
        proyectsListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                for (Proyecto proyect : proyects) {
                    if (proyect.getNombre().equals(newValue)) {
                        // Actualiza las etiquetas con los detalles del proyecto seleccionado
                        nombreLabel.setText(proyect.getNombre());
                        fechaCreacionLabel.setText(proyect.getFechaCreacion().toString());
                        fechaInicioLabel.setText(proyect.getFechaInicio().toString());
                        if (proyect.getFechaFin() != null) {
                            fechaFinLabel.setText(proyect.getFechaFin().toString());
                        } else {
                            fechaFinLabel.setText("N/A");
                        }
                        codigoProyectoLabel.setText(proyect.getCodigoProyecto());
                        palabrasClaveLabel.setText(proyect.getPalabrasClave());
                        tipoProyectoLabel.setText(proyect.getTipoProyecto());
                        activoLabel.setText(proyect.isActivo() ? "Activo" : "Inactivo");
                        calificacionLabel.setText(String.valueOf(proyect.getCalificacion()));
                        auditoraLabel.setText(proyect.getAuditora());
                        codigoLabel.setText(proyect.getCodigo());
                        enCooperacionLabel.setText(proyect.isEnCooperacion() ? "En Cooperación" : "No en Cooperación");
                        bajadaCalificacionLabel.setText(String.valueOf(proyect.getBajadaCalificacion()));
                        fasesLabel.setText(proyect.getFases());
                        selProyect = proyect;
                        break;
                    }
                }
            }
        });

        // Panel superior: Botones para documentos y gráficos
        HBox hboxT = new HBox(10);
        Button btnDocuments = new Button("Documentos");
        Button btnGraficas = new Button("Gráficos");
        hboxT.getChildren().addAll(btnDocuments, btnGraficas);
        // Panel derecho: Información del usuario y edición de proyectos
        VBox vboxR = new VBox(10);
        vboxR.setPadding(new Insets(10));
        Label nameLabel = new Label();
        nameLabel.setText(Usuario.usuario.getNombre());
        Label roleLabel = new Label();
        roleLabel.setText(Usuario.usuario.getRol());

        // Grupo de botones de radio para seleccionar el campo a editar
        ToggleGroup grupoRB = new ToggleGroup();

        RadioButton nombreRB = new RadioButton("Nombre");
        RadioButton fechaCreacionRB = new RadioButton("Fecha de creación");
        RadioButton fechaInicioRB = new RadioButton("Fecha de inicio");
        RadioButton fechaFinRB = new RadioButton("Fecha de fin");
        RadioButton codigoProyectoRB = new RadioButton("Código del proyecto");
        RadioButton palabrasClaveRB = new RadioButton("Palabras clave");
        RadioButton tipoProyectoRB = new RadioButton("Tipo de proyecto");
        RadioButton activoRB = new RadioButton("Activo");
        RadioButton calificacionRB = new RadioButton("Calificación");
        RadioButton auditoraRB = new RadioButton("Auditoría");
        RadioButton codigoRB = new RadioButton("Código");
        RadioButton enCooperacionRB = new RadioButton("En cooperación");
        RadioButton bajadaCalificacionRB = new RadioButton("Bajada de calificación");
        RadioButton fasesRB = new RadioButton("Fases");

        // Asignar los botones de radio al grupo
        nombreRB.setToggleGroup(grupoRB);
        fechaCreacionRB.setToggleGroup(grupoRB);
        fechaInicioRB.setToggleGroup(grupoRB);
        fechaFinRB.setToggleGroup(grupoRB);
        codigoProyectoRB.setToggleGroup(grupoRB);
        palabrasClaveRB.setToggleGroup(grupoRB);
        tipoProyectoRB.setToggleGroup(grupoRB);
        activoRB.setToggleGroup(grupoRB);
        calificacionRB.setToggleGroup(grupoRB);
        auditoraRB.setToggleGroup(grupoRB);
        codigoRB.setToggleGroup(grupoRB);
        enCooperacionRB.setToggleGroup(grupoRB);
        bajadaCalificacionRB.setToggleGroup(grupoRB);
        fasesRB.setToggleGroup(grupoRB);

        // Contenedor para los campos de entrada dinámicos
        VBox inputContainer = new VBox(10);
        Button btnEdit = new Button("Editar");

        // Listener para el grupo de botones de radio
        grupoRB.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                String selectedText = ((RadioButton) newValue).getText();
                inputContainer.getChildren().clear();

                switch (selectedText) {
                    case "Nombre":
                        TextField nombre = new TextField();
                        nombre.setPromptText("Nombre");
                        inputContainer.getChildren().add(nombre);
                        btnEdit.setOnAction(e -> {
                            String nuevoNombre = nombre.getText();
                            if (nuevoNombre.isEmpty()) {
                                JOptionPane.showMessageDialog(null, "El campo 'Nombre' no puede estar vacío.");
                            } else {
                                Consultas.editProyecto(selProyect.getCodigoProyecto(), "nombre", nuevoNombre);
                                Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha editado el proyecto de nombre: " + selProyect.getNombre() + " a " + nuevoNombre + ".");
                                updateList(proyectsListView);
                            }
                        });
                        break;
                    case "Fecha de creación":
                        DatePicker fechacreacion = new DatePicker();
                        fechacreacion.setPromptText("YYYY-MM-DD");

                        inputContainer.getChildren().add(fechacreacion);
                        btnEdit.setOnAction(e -> {
                            LocalDate nuevaFecha = fechacreacion.getValue(); // Obtener el valor seleccionado como LocalDate
                            if (nuevaFecha != null) {
                                String nuevaFechaStr = nuevaFecha.toString(); // Convertir a String en formato YYYY-MM-DD
                                Consultas.editProyecto(selProyect.getCodigoProyecto(), "fecha_creacion", nuevaFechaStr);
                                Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha editado la fecha de creación del proyecto de nombre: " + selProyect.getNombre() + " de: " + selProyect.getFechaCreacion().toString() + " a " + nuevaFechaStr + ".");
                                updateList(proyectsListView);
                            } else {
                                JOptionPane.showMessageDialog(null, "Por favor selecciona una fecha.");
                            }
                        });
                        break;

                    case "Fecha de inicio":
                        DatePicker fechainicio = new DatePicker();
                        fechainicio.setPromptText("YYYY-MM-DD");
                        inputContainer.getChildren().add(fechainicio);
                        btnEdit.setOnAction(e -> {
                            LocalDate nuevaFecha = fechainicio.getValue(); // Obtener el valor seleccionado como LocalDate
                            if (nuevaFecha != null) {
                                String nuevaFechaStr = nuevaFecha.toString(); // Convertir a String en formato YYYY-MM-DD
                                Consultas.editProyecto(selProyect.getCodigoProyecto(), "fecha_inicio", nuevaFechaStr);
                                Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha editado la fecha de inicio del proyecto de nombre: " + selProyect.getNombre() + " de: " + selProyect.getFechaInicio().toString() + " a " + nuevaFechaStr + ".");
                                updateList(proyectsListView);
                            } else {
                                JOptionPane.showMessageDialog(null, "Por favor selecciona una fecha.");
                            }
                        });
                        break;

                    case "Fecha de fin":
                        DatePicker fechafin = new DatePicker();
                        fechafin.setPromptText("YYYY-MM-DD");
                        inputContainer.getChildren().add(fechafin);
                        btnEdit.setOnAction(e -> {
                            LocalDate nuevaFecha = fechafin.getValue(); // Obtener el valor seleccionado como LocalDate
                            if (nuevaFecha != null) {
                                String nuevaFechaStr = nuevaFecha.toString(); // Convertir a String en formato YYYY-MM-DD
                                Consultas.editProyecto(selProyect.getCodigoProyecto(), "fecha_fin", nuevaFechaStr);
                                Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha editado la fecha de finalización del proyecto de nombre: " + selProyect.getNombre() + " de: " + selProyect.getFechaFin().toString() + " a " + nuevaFechaStr + ".");
                            } else {
                                JOptionPane.showMessageDialog(null, "Por favor selecciona una fecha.");
                            }
                            updateList(proyectsListView);
                        });
                        break;


                    case "Código del proyecto":
                        TextField codigoProyecto = new TextField();
                        codigoProyecto.setPromptText("Codigo del proyecto");
                        inputContainer.getChildren().add(codigoProyecto);
                        btnEdit.setOnAction(e -> {
                            String nuevoCodigoProyecto = codigoProyecto.getText();
                            Consultas.editProyecto(selProyect.getCodigoProyecto(), "codigo_proyecto", nuevoCodigoProyecto);
                            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha editado el código de proyecto del proyecto de nombre: " + selProyect.getNombre() + " de " + selProyect.getCodigoProyecto() + " a " + nuevoCodigoProyecto + ".");
                            updateList(proyectsListView);
                        });
                        break;

                    case "Palabras clave":
                        TextArea palabrasClave = new TextArea();
                        palabrasClave.setPromptText("Palabras clave (separadas por comas)");
                        palabrasClave.setPrefRowCount(5);
                        palabrasClave.setPrefColumnCount(20);
                        inputContainer.getChildren().add(palabrasClave);
                        btnEdit.setOnAction(e -> {
                            String nuevasPalabrasClave = palabrasClave.getText();
                            Consultas.editProyecto(selProyect.getCodigoProyecto(), "palabras_clave", nuevasPalabrasClave);
                            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha modificado las palabras clave del proyecto de nombre: " + selProyect.getNombre() + ".");
                            updateList(proyectsListView);
                        });
                        break;

                    case "Tipo de proyecto":
                        TextField tipoProyecto = new TextField();
                        tipoProyecto.setPromptText("Tipo de proyecto");
                        inputContainer.getChildren().add(tipoProyecto);
                        btnEdit.setOnAction(e -> {
                            String nuevoTipoProyecto = tipoProyecto.getText();
                            if (nuevoTipoProyecto.isEmpty()) {
                                JOptionPane.showMessageDialog(null, "El campo 'Tipo de proyecto' no puede estar vacío.");
                            } else {
                                Consultas.editProyecto(selProyect.getCodigoProyecto(), "tipo_proyecto", nuevoTipoProyecto);
                                Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha modificado el tipo de proyecto del proyecto de nombre: " + selProyect.getNombre() + ".");
                                updateList(proyectsListView);
                            }
                        });
                        break;
                    case "Activo":
                        ToggleGroup toggleGroupActivo = new ToggleGroup();
                        RadioButton activo = new RadioButton("Activo");
                        RadioButton inactivo = new RadioButton("Inactivo");
                        activo.setToggleGroup(toggleGroupActivo);
                        inactivo.setToggleGroup(toggleGroupActivo);
                        HBox toggleContainerActivo = new HBox(10, activo, inactivo);
                        inputContainer.getChildren().add(toggleContainerActivo);
                        btnEdit.setOnAction(e -> {
                            boolean isActivo = activo.isSelected();
                            Consultas.activo(selProyect.getCodigoProyecto(), "activo", isActivo ? 1 : 0);
                            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha cambiado el proyecto de nombre: " + selProyect.getNombre() + ", ahora" + (isActivo ? "es activo" : "es inactivo") + ".");
                            updateList(proyectsListView);
                        });
                        break;

                    case "Calificación":
                        Spinner<Double> calificacion = new Spinner<>(0.0, 10.0, 0.0);

                        inputContainer.getChildren().add(calificacion);
                        btnEdit.setOnAction(e -> {
                            int nuevaCalificacion = calificacion.getValue().intValue();
                            Consultas.editProyecto(selProyect.getCodigoProyecto(), "calificacion", String.valueOf(nuevaCalificacion));
                            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha cambiado la calificación del proyecto de nombre: " + selProyect.getNombre() + ", ahora tiene " + nuevaCalificacion + " de calificación.");
                            updateList(proyectsListView);
                        });
                        break;

                    case "Auditoría":
                        TextField auditoria = new TextField();
                        auditoria.setPromptText("Auditoría");
                        inputContainer.getChildren().add(auditoria);
                        btnEdit.setOnAction(e -> {
                            String nuevaAuditoria = auditoria.getText();
                            Consultas.editProyecto(selProyect.getCodigoProyecto(), "auditora", nuevaAuditoria);
                            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha cambiado la auditora del proyecto de nombre: " + selProyect.getNombre() + ", ahora tiene " + nuevaAuditoria + " como auditora.");
                            updateList(proyectsListView);
                        });
                        break;

                    case "Código":
                        TextField codigo = new TextField();
                        codigo.setPromptText("Código");
                        inputContainer.getChildren().add(codigo);
                        btnEdit.setOnAction(e -> {
                            String nuevoCodigo = codigo.getText();
                            Consultas.editProyecto(selProyect.getCodigoProyecto(), "codigo", nuevoCodigo);
                            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha cambiado el código del proyecto de nombre: " + selProyect.getNombre() + ", ahora el código es:  " + nuevoCodigo + ".");
                            updateList(proyectsListView);
                        });
                        break;

                    case "Bajada de calificación":
                        Spinner<Double> bajadaCalificacion = new Spinner<>(-10, 0, 0);
                        inputContainer.getChildren().add(bajadaCalificacion);
                        btnEdit.setOnAction(e -> {
                            int nuevaBajadaCalificacion = bajadaCalificacion.getValue().intValue();
                            Consultas.editProyecto(selProyect.getCodigoProyecto(), "bajada_calificacion", String.valueOf(nuevaBajadaCalificacion));
                            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha cambiado la bajada de calificación del proyecto de nombre: " + selProyect.getNombre() + ", ahora tiene " + nuevaBajadaCalificacion + " de bajada de calificación.");
                            updateList(proyectsListView);
                        });
                        break;

                    case "En cooperación":
                        ToggleGroup toggleGroupCooperacion = new ToggleGroup();
                        RadioButton rbSiCooperacion = new RadioButton("Sí");
                        RadioButton rbNoCooperacion = new RadioButton("No");
                        rbSiCooperacion.setToggleGroup(toggleGroupCooperacion);
                        rbNoCooperacion.setToggleGroup(toggleGroupCooperacion);
                        HBox toggleContainerCooperacion = new HBox(10, rbSiCooperacion, rbNoCooperacion);
                        inputContainer.getChildren().add(toggleContainerCooperacion);
                        btnEdit.setOnAction(e -> {
                            boolean isEnCooperacion = rbSiCooperacion.isSelected();
                            Consultas.activo(selProyect.getCodigoProyecto(), "en_cooperacion", isEnCooperacion ? 1 : 0);
                            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha cambiado el proyecto de nombre: " + selProyect.getNombre() + ", ahora" + (isEnCooperacion ? "está en cooperación" : "no está en cooperación") + ".");
                            updateList(proyectsListView);
                        });
                        break;

                    case "Fases":
                        TextArea fases = new TextArea();
                        fases.setPromptText("Fases (separadas por comas)");
                        fases.setPrefRowCount(5);
                        fases.setPrefColumnCount(20);
                        inputContainer.getChildren().add(fases);
                        btnEdit.setOnAction(e -> {
                            String nuevasFases = fases.getText();
                            Consultas.editProyecto(selProyect.getCodigoProyecto(), "fases", nuevasFases);
                            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha cambiado las fases del proyecto de nombre: " + selProyect.getNombre() + ".");
                            updateList(proyectsListView);
                        });
                        break;

                    default:
                        TextField defaultField = new TextField();
                        defaultField.setPrefWidth(200);
                        inputContainer.getChildren().add(defaultField);
                        btnEdit.setOnAction(e -> Consultas.editProyecto(selProyect.getCodigoProyecto(), "texto", defaultField.getText()));
                        break;
                }
            }
        });
        btnDocuments.onMouseClickedProperty().set(e -> {
            Proyecto.proyecto = selProyect;
            DocumentosVP doc = new DocumentosVP();
            try {
                doc.start(new Stage());
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });

        deleteButton.onMouseClickedProperty().set(e -> {
            if(selProyect != null) {
                Consultas.deleteProyectos(selProyect.getCodigoProyecto());
                Consultas.deleteRelacionados(selProyect.getId());
                Consultas.deleteRelacionados2(selProyect.getId());
            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha eliminado un proyecto de nombre: " + selProyect.getNombre() + ".");
            updateList(proyectsListView);
            } else {
                JOptionPane.showMessageDialog(null, "Selecciona un proyecto.");
            }
        });

        Button btnCreate = new Button("Crear proyecto");

        btnCreate.onMouseClickedProperty().set(e -> {
            NewProyectoV newProyectoV = new NewProyectoV();
            try {
                newProyectoV.start(new Stage());
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });

        btnGraficas.onMouseClickedProperty().set(e -> {
            GráficasVP graficasVP = new GráficasVP();
            try {
                graficasVP.start(new Stage());
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });

        bBusqueda.textProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue != null) {
                dataproyects.clear();
                String searchTerm = newValue.toLowerCase();
                for (Proyecto p : proyects) {
                    if (p.getNombre().toLowerCase().contains(searchTerm) || p.getPalabrasClave().toLowerCase().contains(searchTerm)) {
                        dataproyects.add(p.getNombre());
                    }
                }
                nombreLabel.setText("");
                fechaCreacionLabel.setText("");
                fechaInicioLabel.setText("");
                fechaFinLabel.setText("");
                codigoProyectoLabel.setText("");
                palabrasClaveLabel.setText("");
                tipoProyectoLabel.setText("");
                activoLabel.setText("");
                calificacionLabel.setText("");
                auditoraLabel.setText("");
                codigoLabel.setText("");
                enCooperacionLabel.setText("");
                bajadaCalificacionLabel.setText("");
                fasesLabel.setText("");

                proyectsListView.setItems(dataproyects);
            }
        });

        cbFiltro.valueProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue != null) {
                dataproyects.clear();
                if (!newValue.equals("Todos")) {
                    switch(newValue){

                        case "Activo":
                            for (Proyecto p : proyects) {
                                if (p.isActivo()) {
                                    dataproyects.add(p.getNombre());
                                }
                            }
                            break;

                        case "Inactivo":
                            for (Proyecto p : proyects) {
                                if (!p.isActivo()) {
                                    dataproyects.add(p.getNombre());
                                }
                            }
                            break;

                        case "En cooperación":
                            for (Proyecto p : proyects) {
                                if (p.isEnCooperacion()) {
                                    dataproyects.add(p.getNombre());
                                }
                            }
                            break;

                        case "Sin cooperación":
                            for (Proyecto p : proyects) {
                                if (!p.isEnCooperacion()) {
                                    dataproyects.add(p.getNombre());
                                }
                            }
                            break;

                    }

                    nombreLabel.setText("");
                    fechaCreacionLabel.setText("");
                    fechaInicioLabel.setText("");
                    fechaFinLabel.setText("");
                    codigoProyectoLabel.setText("");
                    palabrasClaveLabel.setText("");
                    tipoProyectoLabel.setText("");
                    activoLabel.setText("");
                    calificacionLabel.setText("");
                    auditoraLabel.setText("");
                    codigoLabel.setText("");
                    enCooperacionLabel.setText("");
                    bajadaCalificacionLabel.setText("");
                    fasesLabel.setText("");

                    proyectsListView.setItems(dataproyects);
                } else {
                    updateList(proyectsListView);
                }
            }

        });
        // Añadir elementos al panel derecho
        vboxR.getChildren().addAll(nameLabel, roleLabel, nombreRB, fechaCreacionRB, fechaInicioRB, fechaFinRB, codigoProyectoRB, palabrasClaveRB,
                tipoProyectoRB, activoRB, calificacionRB, auditoraRB, codigoRB, enCooperacionRB, bajadaCalificacionRB, fasesRB, inputContainer, btnEdit,btnCreate);

        // Configurar el layout principal
        root.setLeft(vboxL);
        root.setCenter(vboxC);
        root.setTop(hboxT);
        root.setRight(vboxR);

        // Actualizar la lista de proyectos
        updateList(proyectsListView);

        // Crear la escena y mostrar la ventana
        Scene scene = new Scene(root, 800, 600);
        primaryStage.setTitle("Gestión de Proyectos");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    // Método para actualizar la lista de proyectos en la interfaz gráfica
    public void updateList(ListView<String> proyectsListView) {
        dataproyects.clear();
        Consultas.checkProyectos(proyects);
        for (Proyecto p : proyects) {
            dataproyects.add(p.getNombre());
        }

        // Limpia las etiquetas de detalles del proyecto
        if (selProyect != null) {
            nombreLabel.setText("");
            fechaCreacionLabel.setText("");
            fechaInicioLabel.setText("");
            fechaFinLabel.setText("");
            codigoProyectoLabel.setText("");
            palabrasClaveLabel.setText("");
            tipoProyectoLabel.setText("");
            activoLabel.setText("");
            calificacionLabel.setText("");
            auditoraLabel.setText("");
            codigoLabel.setText("");
            enCooperacionLabel.setText("");
            bajadaCalificacionLabel.setText("");
            fasesLabel.setText("");
        }

        proyectsListView.setItems(dataproyects);
    }


    public static void main(String[] args) {
        launch(args);
    }
}