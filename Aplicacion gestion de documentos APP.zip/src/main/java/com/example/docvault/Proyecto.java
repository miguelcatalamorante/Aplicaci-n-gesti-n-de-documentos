package com.example.docvault;

import java.sql.Date;

public class Proyecto {
    private int id;
    private String nombre;
    private Date fechaCreacion;
    private Date fechaInicio;
    private Date fechaFin;
    private String codigoProyecto;
    private String palabrasClave;
    private String tipoProyecto;
    private boolean activo;
    private int calificacion;
    private String auditora;
    private String codigo;
    private boolean enCooperacion;
    private int bajadaCalificacion;
    private String fases;

    public Proyecto(int id, String nombre, Date fechaCreacion, Date fechaInicio, Date fechaFin,
                    String codigoProyecto, String palabrasClave, String tipoProyecto,
                    boolean activo, int calificacion, String auditora, String codigo,
                    boolean enCooperacion, int bajadaCalificacion, String fases) {
        this.id = id;
        this.codigo = codigo;
        this.fases = fases;
        this.bajadaCalificacion = bajadaCalificacion;
        this.enCooperacion = enCooperacion;
        this.auditora = auditora;
        this.calificacion = calificacion;
        this.activo = activo;
        this.tipoProyecto = tipoProyecto;
        this.palabrasClave = palabrasClave;
        this.codigoProyecto = codigoProyecto;
        this.fechaFin = fechaFin;
        this.fechaCreacion = fechaCreacion;
        this.fechaInicio = fechaInicio;
        this.nombre = nombre;
    }

    public static Proyecto proyecto = new Proyecto(1, "N/A", Date.valueOf("2024-01-01"),
            Date.valueOf("2024-01-15"), Date.valueOf("2024-06-30"), "N/A-2024-001",
            "N/A, N/A, N/A", "N/A", false, 9,
            "Auditoria N/A", "N/A-123456", true, 2, "N/A, N/A, N/A");

    public Proyecto(String nombre, Date fechaCreacion, Date fechaInicio,
                    String codigoProyecto, String palabrasClave, String tipoProyecto,
                    boolean activo, int calificacion, String auditora, String codigo,
                    boolean enCooperacion, int bajadaCalificacion, String fases) {
        this.codigo = codigo;
        this.fases = fases;
        this.bajadaCalificacion = bajadaCalificacion;
        this.enCooperacion = enCooperacion;
        this.auditora = auditora;
        this.calificacion = calificacion;
        this.activo = activo;
        this.tipoProyecto = tipoProyecto;
        this.palabrasClave = palabrasClave;
        this.codigoProyecto = codigoProyecto;
        this.fechaCreacion = fechaCreacion;
        this.fechaInicio = fechaInicio;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public String getCodigoProyecto() {
        return codigoProyecto;
    }

    public String getPalabrasClave() {
        return palabrasClave;
    }

    public String getTipoProyecto() {
        return tipoProyecto;
    }

    public boolean isActivo() {
        return activo;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public String getAuditora() {
        return auditora;
    }

    public String getCodigo() {
        return codigo;
    }

    public boolean isEnCooperacion() {
        return enCooperacion;
    }

    public int getBajadaCalificacion() {
        return bajadaCalificacion;
    }

    public String getFases() {
        return fases;
    }
}