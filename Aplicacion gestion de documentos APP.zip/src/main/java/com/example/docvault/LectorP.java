package com.example.docvault;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;

public class LectorP extends Application {

    // Listas y variables para usuarios y proyectos
    ArrayList<Usuario> users = new ArrayList<>();
    boolean userConfirm = false;
    boolean passwordConfirm = false;
    ArrayList<Proyecto> proyects = new ArrayList<>();
    ObservableList<String> dataproyects = FXCollections.observableArrayList();

    // Proyecto por defecto seleccionado
    Proyecto selProyect = new Proyecto(420, "N/A", Date.valueOf("2024-01-01"),
            Date.valueOf("2024-01-15"), Date.valueOf("2024-06-30"), "N/A-2024-001",
            "N/A, N/A, N/A", "N/A", false, 9,
            "Auditoria N/A", "N/A-123456", true, 2, "N/A, N/A, N/A");

    // Etiquetas para mostrar información del proyecto seleccionado
    Label nombreLabel = new Label();
    Label fechaCreacionLabel = new Label();
    Label fechaInicioLabel = new Label();
    Label fechaFinLabel = new Label();
    Label codigoProyectoLabel = new Label();
    Label palabrasClaveLabel = new Label();
    Label tipoProyectoLabel = new Label();
    Label activoLabel = new Label();
    Label calificacionLabel = new Label();
    Label auditoraLabel = new Label();
    Label codigoLabel = new Label();
    Label enCooperacionLabel = new Label();
    Label bajadaCalificacionLabel = new Label();
    Label fasesLabel = new Label();

    @Override
    public void start(Stage lectorScene) throws IOException {
        // Cargar proyectos desde una fuente externa
        Consultas.checkProyectos(proyects);

        // Layout principal de la aplicación
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));

        // Panel izquierdo: Búsqueda y lista de proyectos
        VBox vboxL = new VBox(10);
        TextField bBusqueda = new TextField();
        bBusqueda.setPromptText("Búsqueda"); // Campo de búsqueda
        ComboBox<String> cbFiltro = new ComboBox<>();
        cbFiltro.getItems().addAll("Todos", "Activo", "Inactivo", "En cooperación", "Sin cooperación");//filtros
        cbFiltro.setValue("Todos");
        ListView<String> proyectsListView = new ListView<>();
        proyectsListView.setItems(dataproyects); // Conectar lista observable
        vboxL.getChildren().addAll(bBusqueda, cbFiltro, proyectsListView);

        // Panel central: Detalles del proyecto seleccionado
        VBox vboxC = new VBox(10);
        vboxC.setPadding(new Insets(10));
        nombreLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;"); // Estilo de título
        vboxC.getChildren().addAll(nombreLabel, fechaCreacionLabel, fechaInicioLabel, fechaFinLabel,
                codigoProyectoLabel, palabrasClaveLabel, tipoProyectoLabel, activoLabel, calificacionLabel,
                auditoraLabel, codigoLabel, enCooperacionLabel, bajadaCalificacionLabel, fasesLabel);

        // Listener para actualizar los detalles cuando se selecciona un proyecto
        proyectsListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                for (Proyecto proyect : proyects) {
                    if (proyect.getNombre().equals(newValue)) {
                        // Actualizar etiquetas con la información del proyecto seleccionado
                        nombreLabel.setText(proyect.getNombre());
                        fechaCreacionLabel.setText(proyect.getFechaCreacion().toString());
                        fechaInicioLabel.setText(proyect.getFechaInicio().toString());
                        fechaFinLabel.setText(proyect.getFechaFin() != null ? proyect.getFechaFin().toString() : "N/A");
                        codigoProyectoLabel.setText(proyect.getCodigoProyecto());
                        palabrasClaveLabel.setText(proyect.getPalabrasClave());
                        tipoProyectoLabel.setText(proyect.getTipoProyecto());
                        activoLabel.setText(proyect.isActivo() ? "Activo" : "Inactivo");
                        auditoraLabel.setText(proyect.getAuditora());
                        codigoLabel.setText(proyect.getCodigo());
                        enCooperacionLabel.setText(proyect.isEnCooperacion() ? "En Cooperación" : "No en Cooperación");
                        bajadaCalificacionLabel.setText(String.valueOf(proyect.getBajadaCalificacion()));
                        fasesLabel.setText(proyect.getFases());
                        selProyect = proyect;
                        break;
                    }
                }
            }
        });

        // Panel superior: Botones de acciones
        HBox hboxT = new HBox(10);
        Button btnDocuments = new Button("Documentos");
        Button btnGraficas = new Button("Gráficos");
        hboxT.getChildren().addAll(btnDocuments, btnGraficas);

        btnDocuments.onMouseClickedProperty().set(e -> {
            DocumentosVP documentosVP = new DocumentosVP();
            try {
                documentosVP.start(new Stage());
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });

        bBusqueda.textProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue != null) {
                dataproyects.clear();
                for (Proyecto p : proyects) {
                    if(p.getNombre().toLowerCase().contains(newValue.toLowerCase())) {
                        dataproyects.add(p.getNombre());
                    }
                }
                nombreLabel.setText("");
                fechaCreacionLabel.setText("");
                fechaInicioLabel.setText("");
                fechaFinLabel.setText("");
                codigoProyectoLabel.setText("");
                palabrasClaveLabel.setText("");
                tipoProyectoLabel.setText("");
                activoLabel.setText("");
                calificacionLabel.setText("");
                auditoraLabel.setText("");
                codigoLabel.setText("");
                enCooperacionLabel.setText("");
                bajadaCalificacionLabel.setText("");
                fasesLabel.setText("");

                proyectsListView.setItems(dataproyects);
            }
        });

        cbFiltro.valueProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue != null) {
                dataproyects.clear();
                if (!newValue.equals("Todos")) {
                    switch(newValue){

                        case "Activo":
                            for (Proyecto p : proyects) {
                                if (p.isActivo()) {
                                    dataproyects.add(p.getNombre());
                                }
                            }
                            break;

                        case "Inactivo":
                            for (Proyecto p : proyects) {
                                if (!p.isActivo()) {
                                    dataproyects.add(p.getNombre());
                                }
                            }
                            break;

                        case "En cooperación":
                            for (Proyecto p : proyects) {
                                if (p.isEnCooperacion()) {
                                    dataproyects.add(p.getNombre());
                                }
                            }
                            break;

                        case "Sin cooperación":
                            for (Proyecto p : proyects) {
                                if (!p.isEnCooperacion()) {
                                    dataproyects.add(p.getNombre());
                                }
                            }
                            break;

                    }

                    nombreLabel.setText("");
                    fechaCreacionLabel.setText("");
                    fechaInicioLabel.setText("");
                    fechaFinLabel.setText("");
                    codigoProyectoLabel.setText("");
                    palabrasClaveLabel.setText("");
                    tipoProyectoLabel.setText("");
                    activoLabel.setText("");
                    calificacionLabel.setText("");
                    auditoraLabel.setText("");
                    codigoLabel.setText("");
                    enCooperacionLabel.setText("");
                    bajadaCalificacionLabel.setText("");
                    fasesLabel.setText("");

                    proyectsListView.setItems(dataproyects);
                } else {
                    updateList(proyectsListView);
                }
            }

        });

        btnGraficas.onMouseClickedProperty().set(e -> {
            GráficasVP graficasVP = new GráficasVP();
            try {
                graficasVP.start(new Stage());
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });

        // Panel derecho: Información del usuario
        VBox vboxR = new VBox(10);
        vboxR.setPadding(new Insets(10));
        Label nameLabel = new Label(Usuario.usuario.getNombre()); // Nombre del usuario
        Label roleLabel = new Label(Usuario.usuario.getRol());   // Rol del usuario
        vboxR.getChildren().addAll(nameLabel, roleLabel);

        // Asignar paneles al layout principal
        root.setLeft(vboxL);
        root.setCenter(vboxC);
        root.setTop(hboxT);
        root.setRight(vboxR);

        // Actualizar lista de proyectos en la interfaz
        updateList(proyectsListView);

        // Configuración de la ventana principal
        Scene scene = new Scene(root, 800, 600);
        lectorScene.setTitle("DocVault-Lector");
        lectorScene.setScene(scene);
        lectorScene.show();
    }

    // Método para actualizar la lista de proyectos en la interfaz
    public void updateList(ListView<String> proyectListView) {
        dataproyects.clear(); // Limpiar lista observable
        Consultas.checkProyectos(proyects); // Recargar proyectos
        for (Proyecto p : proyects) {
            dataproyects.add(p.getNombre()); // Añadir nombres a la lista
        }
        // Limpiar las etiquetas de detalles
        nombreLabel.setText("");
        fechaCreacionLabel.setText("");
        fechaInicioLabel.setText("");
        fechaFinLabel.setText("");
        codigoProyectoLabel.setText("");
        palabrasClaveLabel.setText("");
        tipoProyectoLabel.setText("");
        activoLabel.setText("");
        calificacionLabel.setText("");
        auditoraLabel.setText("");
        codigoLabel.setText("");
        enCooperacionLabel.setText("");
        bajadaCalificacionLabel.setText("");
        fasesLabel.setText("");

        // Asignar la lista actualizada al ListView
        proyectListView.setItems(dataproyects);
    }

    public static void main(String[] args) {
        launch(args); // Iniciar aplicación
    }
}