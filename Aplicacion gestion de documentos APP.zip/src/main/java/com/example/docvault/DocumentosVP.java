package com.example.docvault;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Date;
import java.util.ArrayList;

public class DocumentosVP extends Application {
    private Blob arch;
    private File selectedFile;
    ArrayList<Documento> documents = new ArrayList<Documento>();
    ObservableList<String> dataDocuments = FXCollections.observableArrayList();
    Documento selDocument = new Documento( "N/A", Date.valueOf("2024-06-30"), arch);


    private Label nombreLabel = new Label();
    private Label fecha_creacionLabel = new Label();

    @Override
    public void start(Stage adminScene) throws IOException {

        Consultas.checkDocument(Proyecto.proyecto.getId(), documents);


        VBox vboxL = new VBox(); // vista vertical izquierda
        Label labelL = new Label("Datos a ingresar");

        TextField nombreField = new TextField();
        nombreField.setPromptText("Nombre del documento");
        FileChooser documentoField = new FileChooser();
        documentoField.setTitle("Documento");
        Button addDocument = new Button("Crear Documento");
        Button editDocument = new Button("Editar Documento");



        vboxL.getChildren().addAll(labelL, editDocument, nombreField, addDocument);


        VBox vboxM = new VBox(); // vista vertical central
        Label labelM = new Label("Documento seleccionado");
        Button delDocument = new Button("Eliminar Documento");

        vboxM.getChildren().addAll(labelM, nombreLabel, fecha_creacionLabel, delDocument);


        VBox vboxR = new VBox(); // vista vertical derecha
        Label labelR = new Label("Lista de Documentos");
        TextField bBusqueda = new TextField();
        bBusqueda.setPromptText("Nombre");
        ListView<String> DocumentListView = new ListView<>();
        DocumentListView.setItems(dataDocuments);
        Button downDocument = new Button("Descargar");
        vboxR.getChildren().addAll(labelR, bBusqueda, DocumentListView, downDocument);

        // muestra la información del Documento seleccionado
        DocumentListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                for (Documento Document : documents) {
                    if (Document.getNombre().equals(newValue)) {
                        nombreLabel.setText(Document.getNombre());
                        fecha_creacionLabel.setText(Document.getFecha_creacion().toString());
                        selDocument = Document;
                        break;
                    }
                }
            }
        });

        HBox hbox = new HBox(vboxL, vboxM, vboxR); // vista en horizontal para acomodar las 3 vistas principales
        hbox.setAlignment(Pos.CENTER);
        hbox.setSpacing(20);


        VBox nameTag = new VBox();

        Label nameLabel = new Label();
        nameLabel.setText(Usuario.usuario.getNombre());
        Label roleLabel = new Label();
        roleLabel.setText(Usuario.usuario.getRol());

        nameTag.getChildren().addAll(nameLabel, roleLabel);

        delDocument.setOnAction(e -> { // elimina el Documento seleccionado
            Consultas.deleteDocument(Proyecto.proyecto.getId(), selDocument.getNombre());
            Consultas.deleteRelacionadoDoc(selDocument.getNombre());
            updateList(DocumentListView);
        });

        editDocument.setOnAction(e -> { // editar Documento

            boolean duplicado = false; // variable para confirmar que no hay duplicados

            for(Documento u : documents){ // verifica que no hay duplicados
                if(u.getNombre().equals(nombreField.getText())){
                    duplicado = true;
                }
            }

            if(duplicado){
                JOptionPane.showMessageDialog(null, "Este nombre de documento ya existe");
            }else {
                String new_name;
                new_name = nombreField.getText();

                Consultas.editDocument(Proyecto.proyecto.getId(), new_name, selDocument.getNombre());
                Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha cambiado el nombre del documento: " + selDocument.getNombre() + " del proyecto de nombre:  " + Proyecto.proyecto.getNombre() + " a: " + new_name + ".");
                updateList(DocumentListView);
            }
        });

        updateList(DocumentListView);
        Button btnDocumento = new Button("Documento");

        btnDocumento.setOnAction(e -> {
            selectedFile = documentoField.showOpenDialog(adminScene);
            JOptionPane.showMessageDialog(null, "Documento " + selectedFile.getName() + " seleccionado.");
        });

        addDocument.setOnAction(e -> { // crear Documento
            if(selectedFile != null) {
                Consultas.addDocument(Proyecto.proyecto.getId(), selectedFile);
                Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha ha creado un documento de nombre: " + selectedFile.getName() + " dentro del proyecto de nombre:  " + Proyecto.proyecto.getNombre() + ".");
                updateList(DocumentListView);
            }
        });

        downDocument.setOnAction(e -> {
            if (nombreLabel.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Debes seleccionar un documento");
            } else {
                String nombreDocumento = nombreLabel.getText();
                Consultas.registrarAcceso(Proyecto.proyecto.getId(), Usuario.usuario.getCorreo(), selDocument.getNombre());
                Consultas.downloadDocument(Proyecto.proyecto.getId(), nombreDocumento);
            }
        });

        bBusqueda.textProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue != null) {
                dataDocuments.clear();
                for (Documento d : documents) {
                    if(d.getNombre().toLowerCase().contains(newValue.toLowerCase())) {
                        dataDocuments.add(d.getNombre());
                    }
                }
                nombreLabel.setText("");
                fecha_creacionLabel.setText("");

                DocumentListView.setItems(dataDocuments);
            }
        });

        GridPane gp = new GridPane(); // vista en cuadricula para acomodar las vistas anteriores
        gp.add(nameTag, 2, 0);
        gp.add(hbox, 1, 1);
        gp.add(btnDocumento, 1, 0);
        gp.setHgap(10);
        gp.setVgap(10);
        gp.setAlignment(Pos.CENTER); // centrar la vista

        if(Usuario.usuario.getRol().equals("Lector")){
            btnDocumento.setDisable(true);
            btnDocumento.setVisible(false);
            vboxL.setVisible(false);
            delDocument.setDisable(true);
            delDocument.setVisible(false);
        }

        Scene scene = new Scene(gp, 1300, 700);
        adminScene.setTitle("DocVault-Documentos");
        adminScene.setScene(scene);
        adminScene.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void updateList(ListView<String> DocumentListView){ // actializa las listas al hacer alguna modificación
        dataDocuments.clear();
        Consultas.checkDocument(Proyecto.proyecto.getId(), documents);
        for(Documento d : documents){
            dataDocuments.add(d.getNombre());
        }
        nombreLabel.setText("");
        fecha_creacionLabel.setText("");

        DocumentListView.setItems(dataDocuments);
    }

}