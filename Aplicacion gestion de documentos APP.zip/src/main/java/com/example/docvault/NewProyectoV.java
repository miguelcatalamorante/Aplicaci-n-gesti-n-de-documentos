package com.example.docvault;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.sql.Date;
import java.time.LocalDate;

public class NewProyectoV extends Application{

    @Override
            public void start(Stage primaryStage) throws Exception {
        // Crear una nueva ventana modal para agregar proyectos
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL); // Bloquea la ventana principal
        stage.setTitle("DocVault-Nuevo proyecto");

        // Layout principal de la ventana
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(10));

        // Campos para introducir información del nuevo proyecto
        TextField nombreField = new TextField();
        nombreField.setPromptText("Nombre del proyecto");
        DatePicker fechaInicioPicker = new DatePicker();
        fechaInicioPicker.setPromptText("Fecha de inicio");
        DatePicker fechaFinPicker = new DatePicker();
        fechaFinPicker.setPromptText("Fecha de finalización");
        TextField codigoField = new TextField();
        codigoField.setPromptText("Código");
        TextField palabrasClaveField = new TextField();
        palabrasClaveField.setPromptText("Palabras clave");
        TextField tipoField = new TextField();
        tipoField.setPromptText("Tipo de proyecto");
        CheckBox activoCheckBox = new CheckBox("Activo");
        TextField auditoraField = new TextField();
        auditoraField.setPromptText("Auditora");
        TextField codigoProyectoField = new TextField();
        codigoProyectoField.setPromptText("Código del proyecto");
        CheckBox enCooperacionCheckBox = new CheckBox("En Cooperación");
        TextField fasesField = new TextField();
        fasesField.setPromptText("Fases del proyecto");

        // Botón para guardar el nuevo proyecto
        Button btnGuardar = new Button("Guardar");
        btnGuardar.setOnAction(e -> {
            LocalDate fecha_creacion = LocalDate.now();
            // Crear un nuevo objeto Proyecto con los datos introducidos
            Proyecto proyecto;
            if(fechaFinPicker == null){
                Proyecto nuevoProyecto = new Proyecto(nombreField.getText(), Date.valueOf(fecha_creacion),
                        Date.valueOf(fechaInicioPicker.getValue()), codigoProyectoField.getText(), palabrasClaveField.getText(),
                        tipoField.getText(), activoCheckBox.isSelected(), 0, auditoraField.getText(), codigoField.getText(),
                        enCooperacionCheckBox.isSelected(), 0, fasesField.getText());
                proyecto = nuevoProyecto;
            }else{
                Proyecto nuevoProyecto = new Proyecto(
                        0, nombreField.getText(), Date.valueOf(fecha_creacion),
                        Date.valueOf(fechaInicioPicker.getValue()), Date.valueOf(fechaFinPicker.getValue()),
                        codigoProyectoField.getText(), palabrasClaveField.getText(), tipoField.getText(),
                        activoCheckBox.isSelected(), 0, auditoraField.getText(), codigoField.getText(),
                        enCooperacionCheckBox.isSelected(), 0, fasesField.getText());
                proyecto = nuevoProyecto;
            }


            // Agregar el proyecto a la base de datos y actualizar la lista
            Consultas.addProyectos(proyecto);
            EscritorP.dataproyects.add(proyecto.getNombre());
            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha creado un proyecto de nombre: " + proyecto.getNombre() + ".");

            // Cerrar la ventana
            stage.close();
        });


        // Añadir los campos y el botón al layout
        vbox.getChildren().addAll(nombreField, fechaInicioPicker, fechaFinPicker,
                codigoField, palabrasClaveField, tipoField, activoCheckBox, auditoraField,
                codigoProyectoField, enCooperacionCheckBox, fasesField, btnGuardar);

        // Configuración de la escena
        Scene scene = new Scene(vbox, 500, 600);
        stage.setScene(scene);
        stage.showAndWait(); // Mostrar la ventana y esperar hasta que se cierre
    }

    public static void main(String[] args) {
        launch(args);
    }

}