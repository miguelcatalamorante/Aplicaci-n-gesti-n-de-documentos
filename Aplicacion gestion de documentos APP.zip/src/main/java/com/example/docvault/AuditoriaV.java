package com.example.docvault;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.ArrayList;

public class AuditoriaV extends Application {
    static ArrayList<String> acciones = new ArrayList<>();
    @Override
    public void start(Stage primaryStage) {

        // Crear ListView y asignar los valores desde el ArrayList
        ListView<String> listView = new ListView<>();
        listView.getItems().addAll(acciones);
        listView.setPrefSize(600, 400);
        updateList(listView);

        VBox nameTag = new VBox();
        Label nameLabel = new Label();
        nameLabel.setText(Usuario.usuario.getNombre());
        Label roleLabel = new Label();
        roleLabel.setText(Usuario.usuario.getRol());
        nameTag.getChildren().addAll(nameLabel, roleLabel);
        nameTag.setAlignment(Pos.CENTER);

        // Crear un GridPane y agregar el ListView
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(nameTag, 0, 0);
        gridPane.add(listView, 0, 1);

        // Crear la escena
        Scene scene = new Scene(gridPane, 800, 700);

        // Configurar el escenario
        primaryStage.setTitle("Auditoría");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void updateList(ListView<String> lv){ // actializa las listas al hacer alguna modificación
        Consultas.checkAuditoria(acciones);
        lv.getItems().addAll(acciones);
    }

}