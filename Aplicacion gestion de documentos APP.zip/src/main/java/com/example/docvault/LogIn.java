package com.example.docvault;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.util.ArrayList;

public class LogIn extends Application { // ventana de Log In
    static ArrayList<Usuario> users = new ArrayList<Usuario>(); // lista donde se almcenan los usuarios de la BDD
    boolean userConfirm = false; // variable para verificar el usuario introducido y darle acceso

    @Override
    public void start(Stage loginScene) throws IOException {

        Consultas.checkUser(users); // hacer la consulta para sacar los usuarios de la BDD

        VBox vbox = new VBox(10);
        Label texto = new Label("Log In");
        TextField correo = new TextField();
        correo.setPromptText("Correo");
        PasswordField password = new PasswordField(); // campo de contraseña para más seguridad
        password.setPromptText("Contraseña");
        Button login = new Button("Iniciar sesión");

        login.setOnAction(e -> { // acción del botón login

            for (Usuario user : users) { // recorre el arrayList de users
                if (user.getCorreo().equals(correo.getText()) && user.getContraseña().equals(password.getText())) { // compara los valores introducidos con los almacenados en la BDD a través del arrayList users
                    userConfirm = true;
                    Usuario.usuario = user; // almacena todos los datos del usuario verificado para su uso posterior
                }
            }

            if(userConfirm){
                System.out.println("Usuario verificado");
                Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha iniciado sesión.");
                loginScene.close();
                changeWindow(Usuario.usuario.getRol()); // accede a la clase changeWindow utilizando el rol del usuario verificado
            } else {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos"); // mensaje de error al introducir datos erroneos
            }

        });

        vbox.getChildren().addAll(texto, correo, password, login);
        vbox.setAlignment(Pos.CENTER);

        //FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(vbox, 1300, 700);
        loginScene.setTitle("DocVault-Login");
        loginScene.setScene(scene);
        loginScene.show();
    }

    public static void main(String[] args) {
        launch();
    }

    public static void changeWindow(String rol) { // accede a la ventana designada dependiendo del rol que el usuario porte

        switch (rol) {

            case "Administrador":
                AdminP adminP = new AdminP();
                try {
                    adminP.start(new Stage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                break;

            case "Lector":
                LectorP lectorP = new LectorP();
                try {
                    lectorP.start(new Stage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                break;

            case "Escritor":
                EscritorP escritorP = new EscritorP();
                escritorP.start(new Stage());
                break;
        }
    }
}