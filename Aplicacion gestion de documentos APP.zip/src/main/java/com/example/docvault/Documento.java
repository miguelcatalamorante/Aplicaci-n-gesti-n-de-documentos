package com.example.docvault;

import java.io.File;
import java.sql.Blob;
import java.text.Normalizer;
import java.sql.Date;

public class Documento {
    private String nombre;
    private Date fecha_creacion;
    private Blob documento;

    public Documento(String nombre, Date fecha_creacion, Blob documento) {
        this.nombre = nombre;
        this.fecha_creacion = fecha_creacion;
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(Date fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

    public Blob getDocumento() {
        return documento;
    }

    public void setDocumento(Blob documento) {
        this.documento = documento;
    }
}