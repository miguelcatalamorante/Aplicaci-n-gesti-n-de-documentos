package com.example.docvault;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.util.ArrayList;

public class AdminP extends Application { // ventana principal del administrador
    ArrayList<Usuario> users = new ArrayList<Usuario>(); // arrayList creado para no llamar siempre a la clase LogIn
    ObservableList<String> dataUsers = FXCollections.observableArrayList(); // necesario para el funcionamiento del listView
    Usuario selUser = new Usuario( "N/A", "N/A", "N/A", "N/A"); // usuario seleccionado en la tabla

    private Label nombreLabel = new Label();
    private Label correoLabel = new Label();
    private Label contraseñaLabel = new Label();
    private Label rolLabel = new Label();

    @Override
    public void start(Stage adminScene) throws IOException {

        Consultas.checkUser(users);


        VBox vboxL = new VBox(); // vista vertical izquierda
        Label labelL = new Label("Datos a ingresar");

        TextField nombreField = new TextField();
        nombreField.setPromptText("Nombre");
        TextField correoField = new TextField();
        correoField.setPromptText("Correo");
        TextField contraseñaField = new TextField();
        contraseñaField.setPromptText("Contraseña");
        ComboBox<String> rolComboBox = new ComboBox<>();
        rolComboBox.getItems().addAll("Lector", "Escritor", "Administrador");
        rolComboBox.setPromptText("Selecciona Rol");
        Button addUser = new Button("Crear Usuario");
        Button editUser = new Button("Editar Usuario");



        vboxL.getChildren().addAll(labelL, editUser, nombreField, correoField, contraseñaField, rolComboBox, addUser);


        VBox vboxM = new VBox(); // vista vertical central
        Label labelM = new Label("Usuario seleccionado");
        Button delUser = new Button("Eliminar usuario");

        vboxM.getChildren().addAll(labelM, nombreLabel, correoLabel, contraseñaLabel, rolLabel, delUser);


        VBox vboxR = new VBox(); // vista vertical derecha
        Label labelR = new Label("Lista de Usuarios");
        TextField bBusqueda = new TextField();
        bBusqueda.setPromptText("Nombre");
        ListView<String> userListView = new ListView<>();
        userListView.setItems(dataUsers);
        vboxR.getChildren().addAll(labelR, bBusqueda, userListView);

        // muestra la información del usuario seleccionado
        userListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                for (Usuario user : users) {
                    if (user.getNombre().equals(newValue)) {
                        nombreLabel.setText(user.getNombre());
                        correoLabel.setText(user.getCorreo());
                        contraseñaLabel.setText(user.getContraseña());
                        rolLabel.setText(user.getRol());
                        selUser = user;
                        break;
                    }
                }
            }
        });

        HBox hbox = new HBox(vboxL, vboxM, vboxR); // vista en horizontal para acomodar las 3 vistas principales
        hbox.setAlignment(Pos.CENTER);
        hbox.setSpacing(20);


        VBox nameTag = new VBox();

        Label nameLabel = new Label();
        nameLabel.setText(Usuario.usuario.getNombre());
        Label roleLabel = new Label();
        roleLabel.setText(Usuario.usuario.getRol());

        nameTag.getChildren().addAll(nameLabel, roleLabel);


        addUser.setOnAction(e -> { // crear usuario
            if (nombreField.getText().isEmpty() || correoField.getText().isEmpty() || contraseñaField.getText().isEmpty() || rolComboBox.getValue().isEmpty()) { // verifica que todos los campos tengan datos
                JOptionPane.showMessageDialog(null, "Debes llenar todos los campos");
            } else {
                for(Usuario u : users){ // verifica que no hay duplicados
                    if(u.getCorreo().equals(correoField.getText())){
                        JOptionPane.showMessageDialog(null, "Este correo de usuario ya existe");
                        return;
                    }
                }
                Consultas.addUser(nombreField.getText(), correoField.getText(), contraseñaField.getText(), rolComboBox.getValue());
                Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha creado un nuevo usuario de correo: " + correoField.getText() + " y rol: " + rolComboBox.getValue() + ".");
                updateList(userListView);
            }
        });

        delUser.setOnAction(e -> { // elimina el usuario seleccionado
            Consultas.deleteUser(selUser.getNombre(), selUser.getRol());
            Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha eliminado un usuario de correo: " + selUser.getCorreo() + " y rol: " + selUser.getRol() + ".");
            updateList(userListView);
        });

        editUser.setOnAction(e -> { // editar usuario

            boolean duplicado = false; // variable para confirmar que no hay duplicados

            for(Usuario u : users){ // verifica que no hay duplicados
                if(u.getCorreo().equals(correoField.getText())){
                    duplicado = true;
                }
            }

            if(duplicado){
                JOptionPane.showMessageDialog(null, "Este correo de usuario ya existe");
            }else {
                String registro = "";
                String correo;
                correo = correoField.getText();
                if (correo.isEmpty()) {
                    correo = selUser.getCorreo();
                } else {
                    registro += "Nuevo correo: " + correo + " ";
                }

                String newName;
                newName = nombreField.getText(); // saca el nombre del campo de texto
                if (newName.isEmpty()) { // si el campo de texto está vacío saca el nombre del usuario seleccionado
                    newName = selUser.getNombre(); // al ser el mismo nombre este no cambiará
                } else {
                    registro += "Nuevo nombre: " + newName + " ";
                }

                String contraseña;
                contraseña = contraseñaField.getText();
                if (contraseña.isEmpty()) {
                    contraseña = selUser.getContraseña();
                } else {
                    registro += "Nueva contraseña: " + contraseña + " ";
                }

                String rol;
                rol = rolComboBox.getValue();
                if (rol.isEmpty()) {
                    rol = selUser.getRol();
                } else {
                    registro += "Nuevo rol: " + rol;
                }

                String oldName;
                oldName = selUser.getNombre();

                Consultas.editUser(newName, correo, contraseña, rol, oldName);
                Consultas.registrarAuditoria(Usuario.usuario.getCorreo(), "Usuario: " + Usuario.usuario.getNombre() + " ha editado los datos del usuario con correo: " + selUser.getCorreo() + " a:\n" + registro + ".");
                updateList(userListView);
            }
        });

        bBusqueda.textProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue != null) {
                dataUsers.clear();
                for (Usuario u : users) {
                    if(u.getNombre().toLowerCase().contains(newValue.toLowerCase())) {
                        dataUsers.add(u.getNombre());
                    }
                }
                nombreLabel.setText("");
                correoLabel.setText("");
                contraseñaLabel.setText("");
                rolLabel.setText("");

                userListView.setItems(dataUsers);
            }
        });

        updateList(userListView);
        Button goToProyectos = new Button("Proyectos");
        goToProyectos.setOnAction(e -> {
            EscritorP escritorP = new EscritorP();
            escritorP.start(new Stage());
        });
        Button goToReg = new Button("Registros");
        goToReg.setOnAction(e -> {
            AuditoriaV auditoriaV = new AuditoriaV();
            auditoriaV.start(new Stage());
        });

        GridPane gp = new GridPane(); // vista en cuadricula para acomodar las vistas anteriores
        gp.add(nameTag, 2, 0);
        gp.add(hbox, 1, 1);
        gp.add(goToProyectos, 1, 0);
        gp.add(goToReg, 0, 0);
        gp.setHgap(10);
        gp.setVgap(10);
        gp.setAlignment(Pos.CENTER); // centrar la vista

        Scene scene = new Scene(gp, 1300, 700);
        adminScene.setTitle("DocVault-Administrador");
        adminScene.setScene(scene);
        adminScene.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void updateList(ListView<String> userListView){ // actializa las listas al hacer alguna modificación
        dataUsers.clear();
        Consultas.checkUser(users);
        for(Usuario u : users){
            dataUsers.add(u.getNombre());
        }
        nombreLabel.setText("");
        correoLabel.setText("");
        contraseñaLabel.setText("");
        rolLabel.setText("");

        userListView.setItems(dataUsers);
    }

}